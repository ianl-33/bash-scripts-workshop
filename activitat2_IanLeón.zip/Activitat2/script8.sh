#!/bin/bash

read -p "Introdueix l'usuari: " usuari

read -s -p "Introdueix la contrasenya: " contrasenya

echo "Has introduit l'usuari $usuari amb la contrasenya $contrasenya" 
