#!/bin/bash

echo "$*" | tr ' ' '\n'
echo "S'han utilitzat $# arguments"
