#!/bin/bash

echo -n "Introdueix el nom d'una variable: "
read nom_variable

echo -n "Introdueix el valor de la variable: "
read valor_variable

echo "La variable que has creat es $nom_variable amb el valor $valor_variable"

