#!/bin/bash

echo "Introdueix una vaiable global: "
read variable_global

echo "Valor de retorn de l'última ordre executada: $?"

echo "Arguments: $@"

echo "PID del current Shell: $$"

