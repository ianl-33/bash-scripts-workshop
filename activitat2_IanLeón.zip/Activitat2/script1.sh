#!/bin/bash

echo "Variables globals"
echo "SHELL = $SHELL"
echo "DISPLAY = $DISPLAY"
echo "HOME = $HOME"
echo "PATH = $PATH"
echo "MANPATH = $MANPATH"
echo "PS1 = $PS1"
echo "PS2 = $PS2"
echo "USER = $USER"
echo "TERM = $TERM"
echo "PWD = $PWD"

echo "Arguments del shell: $#"
echo "Valor retornat per l'ultima comanda: $?"
echo "El PID del shell: $$"

