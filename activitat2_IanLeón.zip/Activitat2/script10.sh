#!/bin/bash

echo "Usuari:$USER"

whoami

echo "Directori personal:$HOME"

echo "Directori actual:$PWD"

echo "Contingut del directori actual:"
ls

echo "Elements que hi ha en aquest directori:"
(ls | wc -l)

echo "El PID del Shell:$$"

echo "Codi de retorn de l'últim ordre:$?"









