#!/bin/bash

echo "Primer argument: $1"
echo "Segon argument: $2"
echo "Tercer argument: $3"
echo "Quart argument: $4"
echo "Cinqué argument: $5"

echo "Nom de l'script: $0"
