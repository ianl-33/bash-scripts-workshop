#!/bin/bash

echo "$*"

echo "$@"
