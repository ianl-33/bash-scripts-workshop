#!/bin/bash

echo "Analitzant fitxer..."

echo "Nom del fitxer a analitzar: "
read fitxer

echo "Procés completat! Revisa resultats.log i errors.log" >> resultats.log 2>> errors.log
echo "===============================" >> resultats.log 2>> errors.log
echo "Fitxer analitzat: $fitxer" >> resultats.log 2>> errors.log

echo "Línies útils: $(cat "$fitxer" 2>> errors.log | grep -v '^$' | wc -l)" >> resultats.log 2>> errors.log

echo "Paraules totals: $(cat "$fitxer" 2>> errors.log | wc -w)" >> resultats.log 2>> errors.log

echo "Caràcters totals: $(cat "$fitxer" 2>> errors.log | wc -m)" >> resultats.log 2>> errors.log

echo "Data: $(date)" >> resultats.log 2>> errors.log

echo "Executat per: $USER" >> resultats.log 2>> errors.log
echo "Directori: $PWD" >> resultats.log 2>> errors.log

echo "PID Shell: $$" >> resultats.log 2>> errors.log

echo "===============================" >> resultats.log 2>> errors.log 
