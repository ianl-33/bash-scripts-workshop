#!/bin/bash

echo "$*" | tr ' ' '\n'

echo "Nombre d'arguments: $#"
