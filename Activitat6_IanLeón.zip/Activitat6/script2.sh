#!/bin/bash

#comprovació del paràmetre
if [ -z "$1" ]; then
    echo "Error: has d'introduir un nom d'usuari."
    exit 1
fi

USUARI="$1"

continuar="si"

while [ "$continuar" == "si" ]; do

    echo "GESTIÓ DE L'USUARI: $USUARI"
    echo "Escull una opció:"
    echo "1) Comprovar si té drets d'administrador"
    echo "2) Comprovar si l'usuari existeix"
    echo "3) Comprovar si el directori personal és vàlid o existeix"
    echo "4) Sortir"

    read -p "Opció > " opcio

    case "$opcio" in
        1)
            #es comprova si l'usuari pertany al grup administrador
            #llista els grups i busca amb el grep
            if groups "$USUARI" 2>/dev/null | grep -q "\bsudo\b"; then
                echo "L'usuari $USUARI té drets d'administrador"
            else
                echo "L'usuari $USUARI no té drets d'administrador."
            fi
            ;;
        2)
            # amb id dona informació de l'usuari.
            # 2>/dev/null que no surtin els errors per pantalla.
            if id "$USUARI" >/dev/null 2>&1; then
                echo "L'usuari $USUARI existeix"
            else
                echo "L'usuari $USUARI no existeix"
            fi
            ;;
        3)
            #ruta del directori en /etc/passwd
            #es buca la línia de l'usuari, i agafa el camp 6 que es la ruta
            directori=$(grep "^$USUARI:" /etc/passwd | cut -d: -f6)

            # Si el directori està buit, és que l'usuari no existeix
            if [ -z "$directori" ]; then
                echo "No existeix la ruta perquè l'usuari no existeix"
            else
                # -d comprova si és un directori
                if [ -d "$directori" ]; then
                    echo "El directori $directori existeix"
                else
                    echo "El directori $directori no existeix."
                fi
            fi
            ;;
        4)
            echo "Sortint"
            #es canvia la variable per trencar el bucle
            continuar="no"
            ;;
        *)
            echo "L'opció que has escollit no es correcta"
            ;;
    esac

done
