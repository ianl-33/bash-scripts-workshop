#!/bin/bash

#es comprova que hi ha un usuario i una IP
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Error: no hi han paràmetres"
    echo "Exemple: ./ssh_remot.sh usuari_prova 192.168.5.8"
    exit 1
fi

USUARI="$1"
IP="$2"

echo "Estàs connectat a la IP"

#tot el que hi ha entre COMANDES i COMANDES s'executarà a la màquina REMOTA

ssh -T "$USUARI@$IP" << 'COMANDES'

    echo "Usuari amb el que estic:"
    whoami

    echo "Rura on estàs situat:"
    pwd

COMANDES

echo "La connexió s'ha tancat"
