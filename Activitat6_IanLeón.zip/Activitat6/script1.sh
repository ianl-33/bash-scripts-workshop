#!/bin/bash

seguir="si"

while [ "$seguir" == "si" ]; do #Mentres la variable sigui si el bucle continua
    echo "ESPIRAL D'EMOCIONS"
    echo "¿Vols continuar avançant"
    echo " 1) Si, continuar (obrir enllaç)"
    echo " 2) No, sortir"
    read -p "Escull una opció:" opcio

    case "$opcio" in #case per veure que fe
        1)
            echo "Obrint l'enllaç"

            #comanda per obrir l'enllaç
            xdg-open "https://youtu.be/jaLDoWqIq2M"

            #ara canvio la variable a no perquè el bucle termini
            seguir="no"
            ;;
        2)
            echo "Sortint de l'espiral"

            #ara canvio la variable a no perquè el bucle termini
            seguir="no"
            ;;
        *)
            #si hi ha alguna opció que no és vàlida
            echo "Opció no vàlida. Intentau de nou"
            ;;
    esac

done

