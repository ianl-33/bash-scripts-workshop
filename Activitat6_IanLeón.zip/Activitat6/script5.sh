#!/bin/bash

#llista de servidors
#IPs de google i una IP aleatoria.
SERVIDORS=("8.8.8.8" "google.com" "192.168.1.88" "1.1.1.1")

#nom de l'arxiu de registre
LOG_FILE="xarxa.log"

#aquesta funció crea l'arxiu de log amb una capçalera
inicialitzar_log() {
    cat << CAPCALERA > "$LOG_FILE"

   Estat dels servidors:
   Data d'inici: $(date)

CAPCALERA
    echo "Arxiu de log inicialitzat: $LOG_FILE"
}

#aquesta funció rep una IP, fa un ping i decideix què escriure
comprovar_servidor() {
    local ip="$1"

    #es fa un ping d'un paquet, i espero com a màxim 1 segon
    ping -c 1 -W 1 "$ip" > /dev/null 2>&1

    #capturo el codi de sortida del ping
    #si és 0 és un èxit perquè respon
    #si és un altre és un error perquè no respon
    case "$?" in
        0)
            ESTAT="ONLINE"
            MISSATGE="El servidor $ip està operatiu"
            ;;
        *)
            ESTAT="OFFLINE"
            MISSATGE="El servidor $ip no respon."
            ;;
    esac

    echo "La ip $ip està $ESTAT"

    #fer un registre al log
    #afegeixo la línia al final de l'arxiu
    echo "[$(date '+%H:%M:%S')] - $ip : $ESTAT" >> "$LOG_FILE"
}

echo "Iniciant el monitoratge de servidors"

#crido a la funció per crear la capçalera
inicialitzar_log

#faig un bucle per recórrer la llista
for server in "${SERVIDORS[@]}"; do
    #crido la funció de comprovació per a cada servidor
    comprovar_servidor "$server"
done





