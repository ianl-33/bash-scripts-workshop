#!/bin/bash

ls /etc | grep conf > directori.txt
