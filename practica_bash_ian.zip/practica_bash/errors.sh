#!/bin/bash

cat no_existe 2> errors.log
echo "Alguna cosa ha fallat! Revisa errors.log"
