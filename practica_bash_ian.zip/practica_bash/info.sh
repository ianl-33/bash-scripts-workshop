#!/bin/bash

echo "Ian 25/09/2025"
date
pwd
