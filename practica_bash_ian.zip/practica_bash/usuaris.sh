#!/bin/bash

who | wc -l > usuaris.txt
