#!/bin/bash

cat /etc/passwd > llista.txt
cat /etc/passwd >> llista.txt
