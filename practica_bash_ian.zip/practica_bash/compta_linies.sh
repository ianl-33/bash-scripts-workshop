#!/bin/bash

# Nom: Ian
# Data: 25/09/2025
# L'script mostra per pantalla un text,
#després llegeix el contingut del fitxer /etc/passwd,
#si hi ha errors els mostra a errors.log, elimia les linies buides,
#compta les línies que queden  i ho escriu en linies.log,
#i al final de linies.log, mostra la data i hora de quan ha fet el recompte,
#i per últim, mostra per pantalla un missatge

echo "Començant el recompte de línies útils..."

cat /etc/passwd 2> errors.log | grep -v '^$' | wc -l  > linies.log

date >> linies.log

echo "Procés completat! Consulta linies.log i errors.log"
