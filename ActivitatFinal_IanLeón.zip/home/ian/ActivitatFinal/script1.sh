#!/bin/bash

#Defineixo variables per al ssh
USUARIO="ian"
IP="172.16.10.240"

llave_ssh=$(cat ~/.ssh/id_rsa.pub)

#Em conecto per ssh i tot el que hi ha a dins del EOF es guarda en un arxiu log
ssh "$USUARIO"@"$IP" <<EOF >> /home/ian/ActivitatFinal/registros.log 2>&1 #Guardo les comprovacions en un arxiu log i també si hi han errors
    #Configuro la clau pública en el servidor per tenir accés sense contrasenya
    mkdir -p ~/.ssh
    echo "$llave_ssh" >> ~/.ssh/authorized_keys
    chmod 700 ~/.ssh
    chmod 600 ~/.ssh/authorized_keys


if ! command -v nmap &> /dev/null; then  #comprovar si nmap existeix
    echo "Nmap no està instalat, instalando..."
    sudo apt-get update && sudo apt-get install -y nmap  #Si no existeix l'instal·lo
fi

#Defineixo les funcions per monitoritzar
memoria_ram () {
     echo ""
     echo "Comprovant memòria RAM..."
     free -m
}

discos () {
     echo ""
     echo "Comprovant discos..."
     df -h
}

hora () {
    echo ""
    echo "Comprovant hora..."
    uptime
}

processos_cpu () {
    echo ""
    echo "5 processos de la cpu..."
    ps -eo pcpu,pid,user,args | sort -k 1 -r | head -6  #Llisto processos i mostro els 5 primers
}

ports () {
    echo ""
    echo "Comprovant port oberts..."
    nmap localhost
}


#Execució de les funcions
memoria_ram
discos
hora
processos_cpu
ports

EOF

cron="0 8 * * 1 /home/ian/ActivitatFinal/script1.sh" #variable per el crontab

crontab -l 2>/dev/null | grep -F "$cron" > /dev/null #comprovar si ja existeix en el crontab el script
if [ $? -ne 0 ]; then
    # Si no existeix ho afegeixo en el crontab
    (crontab -l 2>/dev/null; echo "$cron") | crontab -
    echo "El script s'ha programat en el Cron"
else
    echo "El script ja està programat en el Cron"
fi


