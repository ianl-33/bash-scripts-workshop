#!/bin/bash

opcio=0

while [ "$opcio" -ne 3 ]
do
    echo "Menú"
    echo "1) Mostrar data i hora actual"
    echo "2) Comprovar si existeix un fitxer"
    echo "3) Sortir"

    read -p "Selecciona una opció (1-3): " opcio

    #1.Data i Hora
    if [ "$opcio" -eq 1 ]; then
        echo "La data i hora actual és: $(date)"

    #2. Comprovar fitxer
    elif [ "$opcio" -eq 2 ]; then
        read -p "Introdueix la ruta o nom del fitxer: " fitxer

        if [ -f "$fitxer" ]; then
            echo "El fitxer '$fitxer' existeix."
        else
            echo "El fitxer '$fitxer' no existeix."
        fi

    #3. Sortir
    elif [ "$opcio" -eq 3 ]; then
        echo "Sortint!"

    # Opció no vàlida
    else
        echo "Error: '$opcio' no és una opció vàlida."
        opcio=0
    fi
done
