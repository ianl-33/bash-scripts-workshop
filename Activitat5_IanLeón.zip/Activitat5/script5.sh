#!/bin/bash

ruta=""

until [ -d "$ruta" ]; do #Hasta que se introduzca un directorio válido

	read -p "Introdueix la ruta d'un directori: " ruta

	if [ ! -d "$ruta" ]; then

		echo "La ruta no existeix"
	fi
done

permisos=$(ls -ld "$ruta")
echo "Permisos del directori: $permisos"

permisos=$(ls -ld "$ruta" | cut -d ' ' -f 1)
echo "Permisos: $permisos"

# el type f per buscar arxius i type d per buscar directoris
num_archivos=$(find "$ruta" -maxdepth 1 -type f | wc -l) #maxdepth per no busar subcarpetes
num_carpetas=$(find "$ruta" -maxdepth 1 -type d | grep -v "^$ruta$" | wc -l)

echo "Número d'arxius: $num_archivos"
echo "Número de carpetes: $num_carpetas"

#Nombres de archivos y carpetas
echo "Noms d'arxius i carpetes:"
ls -F "$ruta"

