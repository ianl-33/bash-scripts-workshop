#!/bin/bash

comptador=0
num1=0
num2=0
num3=0

echo "Introdueix 3 números enters:"

until [ "$comptador" -eq 3 ] #Es repeteix fins que el comptador sigui igual a 3
do
    read -p "Introdueix el valor número $((comptador + 1)): " entrada

    # Es comprova si l'entrada és un número enter

	if [[ "$entrada" =~ ^-?[0-9]+$ ]]; then  # Expressió regular per comprovar-ho
        	comptador=$((comptador + 1))

        # Es guarda el valor a la variable corresponent segons el torn
        	if [ "$comptador" -eq 1 ]; then
			num1="$entrada";
		fi
        	if [ "$comptador" -eq 2 ]; then
			num2="$entrada";
		fi
        	if [ "$comptador" -eq 3 ]; then
			num3="$entrada";
		fi
	else
        echo "Error: el valor '$entrada' no és un número enter vàlid."
    	fi
done

# Operacions
suma=$((num1 + num2 + num3))
producte=$((num1 * num2 * num3))

# El més gran i el més petit
# El primer és el més gran i el més petit
maxim="$num1"
minim="$num1"

# Comparem amb el segon i tercer per al màxim
if [ "$num2" -gt "$maxim" ]; then
	maxim="$num2";
	fi
if [ "$num3" -gt "$maxim" ]; then
	maxim="$num3";
	fi

# Comparem amb el segon i tercer per al mínim
if [ "$num2" -lt "$minim" ]; then
	minim="$num2";
	fi
if [ "$num3" -lt "$minim" ]; then
	minim="$num3";
	fi

# Resultats finals
echo "Suma total: $suma"
echo "Producte total: $producte"
echo "El número més gran és: $maxim"
echo "El número més petit és: $minim"
