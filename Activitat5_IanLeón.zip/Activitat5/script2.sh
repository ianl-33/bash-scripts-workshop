#!/bin/bash

num_positius=0
num_negatius=0
num_zeros=0

for numero in "$@";do

	if [[ "$numero" =~ ^-?[0-9]+$ ]] then
		if [[ "$numero" -gt 0 ]]; then
		((num_positius++))
		elif [[ "numero" -lt 0 ]]; then
		((num_negatius++))
		elif [[ "numero" -eq 0 ]]; then
		((num_zeros++))
		fi
	else
	echo "El $numero no és vàlid"
	fi
done

echo "Nombres positius: $num_positius"
echo "Nombres negatius: $num_negatius"
echo "Nombres iguals a 0: $num_zeros"
