#!/bin/bash

read -p "Introde el archivo que quieres analizar: " archivo

lineas=$(wc -l < "$archivo")
> temporal.txt

for lineas in (cut "$archivo")
do
archivo_limpio="${lineas%%#*}"

echo "$archivo_limpio" >> temporal.txt

done

mv temporal.txt "$archivo"
echo "Archivo limpio de comentarios"


read -p "Introduce una palabra que quieras buscar: " palabra

if grep -q "$palabra" "$archivo"; then
	echo "La palabra '$palabra' sí que existe"
else
	echo "La palabra '$palabra' no existe"
fi


for (( ; ; )) #bucle infinito
do
   read -p "Introduce una frase para añadir: " frase
   echo "$frase" >> "$archivo" #guardar la frase en el archivo
   echo "La frase se ha guardado"
done


