#!/bin/bash

echo "El joc de pedra, paper o tisora"

# Variable par repetir el joc
repetir="y"

while [[ "$repetir" == "y" ]]
do
    echo "Escogeix una opció:"
    echo "1. Pedra"
    echo "2. Paper"
    echo "3. Tisores"
    read -p ">" jugador

    # Es genera la jugada (1, 2 o 3)
    consola=$((1 + RANDOM % 3))

    # Primer: És un empat
    if [[ "$jugador" -eq "$consola" ]] then
        echo "Empat"

    # Segon: Guanya el jugador
    # (Pedra vs Tisora) o (Paper vs Pedra) o (Tisora vs Paper)
    elif [[ ("$jugador" -eq 1 && "$consola" -eq 3) || ("$player" -eq 2 && "$consola" -eq 1) || ("$player" -eq 3 && "$consola" -eq 2) ]]
    then
        echo "Has guanyat!"
    # Tercer: Has perdut!
    else
        echo "Has perdut"
    fi

    echo "Tú has escollit: $jugador i Bash ha escollit: $consola"
    read -p "¿Vols tornar a jugar? (y/n): " repetir
done
