#!/bin/bash

arxiu="paraules.txt"

if [ -e "$arxiu" ]; then
	echo "L'arxiu '$arxiu' ja existeix."
else
	echo "L'arxiu '$arxiu' no existeix."
	touch "$arxiu"
	echo "Arxiu creat"
fi

read -p "Introdueix una frase: " paraules

while [ "$paraules" != ":>" ]; do

	if [ "$paraules" == ":>" ]; then
        echo "Desada finalitzada"
        break
    	fi
	echo "$paraules" >> "$arxiu"
	echo "S'han guardat les paraules en l'arxiu"
done
