#!/bin/bash

cut -d: -f1 /etc/passwd | grep '[A-Z]' #Agafa la columna de noms de /etc/passwd i filtra amb majúscules

usuari="no"
nom_usuari=""

while [ "$usuari" == "no" ]; do
	read -p "Introdueix un nom d'usuari del sistema: " nom_usuari

	if id "$nom_usuari" &> /dev/null; then
        	usuari="si" # Si el exit code és 0, l'usuari existeix

    	else
        	echo "L'usuari '$nom_usuari' no existeix."
    	fi
done

echo "Dades de l'usuari '$nom_usuari':"

echo "1. Identificadors i grups:"
id "$nom_usuari"

echo " "

echo "2. Informació del fitxer passwd:"

grep "^$nom_usuari:" /etc/passwd

echo " "
echo "3. Informació del fitxer shadow:"

sudo grep "^$nom_usuari:" /etc/shadow 2>/dev/null
