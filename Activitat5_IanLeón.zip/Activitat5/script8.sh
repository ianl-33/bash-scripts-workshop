#!/bin/bash

valida=0 #Si la contrasenya és correcte. El 0 és no i 1 és sí

echo "Nova contrasenya"

while [ "$valida" -eq 0 ]
do

    read -p "Introdueix la contrasenya: " contrasenya

    error=0

    #Comprovar longitud de mínim 8
    if [ "${#contrasenya}" -lt 8 ]; then
        echo "Error: Ha de tenir mínim 8 caràcters."
	error=1
    fi

    #Comprovar si té una majúscula
    if [[ "$contrasenya" != *[A-Z]* ]]; then
        echo "Error: Falta alguna majúscula."
	error=1
    fi

    #Comprovar si té un número
    if [[ "$contrasenya" != *[0-9]* ]]; then
        echo "Error: Falta algun número."
	error=1
    fi

    #Si no hi ha cap error
    if [ "$error" -eq 0 ]; then
        echo "La contrasenya és segura!"
	valida=1 #Trencar el bucle while
    else
        echo "Torna-ho a intentar."
    fi
done
