#!/bin/bash

url="www.ies-sabadell.cat"

#Aquest bucle es repetiex mentres no hi hagi conexió
#Fer ping. Si falla, entra en el bucle.
until ping -c 1 "$url" &> /dev/null
do
    echo "No hi ha conexió a $url. Tornant a intentar-ho en 5 segons"
    #Esperem 5 segons
    sleep 5
done

#Si el bucle termina, hi ha conexió
echo "Conexió amb éxit."

#Ara s'obre Firefox amb la URL indicada
firefox "$url"
