#!/bin/bash

echo "Introdueix un número: "
read numero

if [[ $numero -eq 0 ]]; then
echo "El numero és 0"

else 
echo "El número no és 0"

fi
