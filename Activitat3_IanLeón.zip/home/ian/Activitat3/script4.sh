#!/bin/bash

if [[ $# -eq 3 ]]; then
echo "Hi ha tres arguments"

else
echo "No hi ha tres arguments"

fi
