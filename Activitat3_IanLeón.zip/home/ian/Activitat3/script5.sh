#!/bin/bash

fitxer="$1"

if [[ $# -eq 0 ]] || [[ $# -gt 1 ]]; then
echo "Ús incorrecte de l'script"
exit
fi

if [[ ! -e $fitxer ]]; then
echo "El fitxer no existeix"
exit
fi

file "$fitxer"

[[ -r $fitxer ]] && echo "El $fitxer és llegible"

[[ -w $fitxer ]] && echo "El fitxer és editable"

[[ -x $fitxer ]] && echo "El fitxer és executable"

