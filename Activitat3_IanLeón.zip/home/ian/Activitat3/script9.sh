#!/bin/bash

path="$1"

fitxer="$2"

if [[ -f $path ]]; then
echo "No és un directori"
exit
fi

if [[ ! -e $path ]]; then
echo "El directori no existeix"
exit
fi

if [[ -e $fitxer ]]; then
echo "El fitxer ja exiteix."
read -p "Vols sobrescriure'l? (s/n): " resposta
if [[ $resposta = "n" ]]; then
echo "S'ha cancel·lat l'operació"
exit
fi
fi

tar -czf "$fitxer" -C "$(dirname "$path")" "$(basename "$path")"
