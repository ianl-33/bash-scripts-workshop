#!/bin/bash

argument="$#"

operacio="$1"
numero1="$2"
numero2="$3"

if [[ $argument -ne 3 ]]; then
echo "No hi han tres arguments"
exit
fi

if [[ $operacio != "add" ]] && [[ $operacio != "substract" ]] && [[ $operacio != "multiply" ]] && [[ $operacio != "divide" ]]; then
echo "L'operació no és vàlida"
exit
fi

if [[ $operacio = "divide" ]] && [[ $numero2 -eq 0 ]]; then
echo "L'operació no és vàlida. No es pot dividir per zero"
exit
fi

if [[ $operacio = "add" ]]; then
resultat=$((numero1 + numero2))

elif [[ $operacio = "substract" ]]; then
resultat=$((numero1 - numero2))

elif [[ $operacio = "multiply" ]]; then
resultat=$((numero1 * numero2))

else
resultat=$((numero1 / numero2))
fi

echo "El resultat és $resultat"



