#!/bin/bash

fitxer="$1"

paraula="$2"

if [[ ! -e $fitxer ]]; then
echo "El fitxer no existeix"
exit
fi

if [[ $fitxer != *.txt && $fitxer != *.csv ]]; then
echo "EL fitxer ha de ser .txt o .csv"
exit
fi

linies=$(grep -i -c $paraula $fitxer)

if [[ $linies -eq 0 ]]; then
echo "No hi ha cap línia amb la paraula $paraula"

else
echo "Hi han $linies línies que contenen la paraula $paraula"

fi
