#!/bin/bash

path="$1"

if [[ -r $path ]]; then
echo "El fitxer és llegible"
else
echo "El fitxer no és llegible"
fi

if [[ -w $path ]]; then
echo "El fitxer és editable"
else
echo "El fitxer no és editable"
fi

if [[ -x $path ]]; then
echo "El fitxer és executable"
else
echo "El fitxer no és executable"
fi




