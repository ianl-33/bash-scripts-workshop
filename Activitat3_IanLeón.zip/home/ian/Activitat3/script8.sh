#!/bin/bash

path="$1"

extensio="${path##*.}"

if [[ -d $path ]]; then
echo "És un directori"
fi

if [[ -f $path ]]; then
echo "És un fitxer amb extensió $extensio"
fi


