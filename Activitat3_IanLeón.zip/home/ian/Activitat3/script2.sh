#!/bin/bash

echo "Introdueix un número: "
read numero

if [[ $numero -lt 0 ]]; then
echo "El numero és negatiu"

else 
echo "El número no és negatiu"

fi
