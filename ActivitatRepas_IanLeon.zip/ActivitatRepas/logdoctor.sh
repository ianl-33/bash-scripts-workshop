#!/bin/bash

echo "Log Doctor - analitzador de logs"


if [[ -n "$1" ]]; then  #Retorna un output 0 (=true) si string no està buit
    log_arxiu="$1"
else
    read -p "Introdueix el nom del log: " log_arxiu
fi


while [[ ! -f "$log_arxiu" || ! -r "$log_arxiu" ]]; do  #si no existeix o no es llegible
    echo "Error: el fitxer '$log_arxiu' no existeix o no es pot llegir"
    read -p "Torna a introduir el nom del log: " log_arxiu
done

echo "El fitxer '$log_arxiu' s'ha carregat correctament."

#Variables
linies=$(wc -l < "$log_arxiu")
errors=$(grep -c "ERROR" "$log_arxiu")
warnings=$(grep -c "WARNING" "$log_arxiu")

echo "Linies totals: $linies"
echo "Linies amb error: $errors"
echo "Linies amb warnings: $warnings"

read -p "Quants infomes vols?: " num_informes
while ! [[ "$num_informes" =~ ^[0-9]+$ ]]; do #revisa si hi ha un enter vàlid
    echo "No és vàlid. Ha de ser un número enter"
    read -p "Quants informes vols?: " num_informes
done

for (( i=1; i<=num_informes; i++ )); do  #bucle per crear n arxius.
    informe="informe_$i.txt"

    echo "Fitxer analitzat: $log_arxiu" >> "$informe"
    echo "Linies totals: $linies" >> "$informe"
    echo "Errores: $errors" >> "$informe"
    echo "Warnings: $warnings" >> "$informe"
done





